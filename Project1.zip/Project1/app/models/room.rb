class Room < ApplicationRecord
end
