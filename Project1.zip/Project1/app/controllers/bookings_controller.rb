class BookingsController < ApplicationController
  before_action :set_booking, only: [:show, :edit, :update, :destroy]
  @@hello=nil
  # GET /bookings
  # GET /bookings.json
  def index
    @bookings = Booking.all
    if(@@hello!=nil)
      @bookings=@@hello
    puts @tan
  else

  end
end
  # GET /bookings/1
  # GET /bookings/1.json
  def show
    admin="username"
    sql="select * from bookings where id ='"+admin
    @showing_booking=Booking.find_by_sql(sql)

  end

  # GET /bookings/new
  def new
    @booking = Booking.new
  end

  # GET /bookings/1/edit
  def edit

  end


  def cancle
      @bookings_cancle= Booking.find(params[:id])
      @bookings_cancle.destory

  end

  def release_room
    current_time=Time.new
    admin="admin"
    sql="select * from bookings where id ='"+admin+"' and date ='#{current_time}'"
   # @recordbookings=find_by_sql(sql)
    @recordbookings = Booking.find(params[:id])
    hours=current_time.hour
    minute=current_time.min
    timeslot=hours*2+minute/30
    @recordbookings.endtime=timeslot
    @recordbookins.update(entime: timeslot)
    redirect_to show_bookings_path

  end

  def process_search
      @room = Room.new(room_params)
      currentime=Time.new
      time="2016-09-18"
      ab="select * from bookings where roomid in (select roomid from rooms where "
      if(@room.size!=nil)
        ab=ab+"size = '#{@room.size}'"
      end
      if(@room.bulding!="")
        ab=ab+"and bulding ='#{@room.bulding}'"
      end
      if(@room.roomid!=nil)
        ab=ab+"and roomid = '#{@room.roomid}'"
      end
      ab="#{ab}) and bookday > '#{currentime.strftime('%Y-%m-%d')}'"

      @@hello=Booking.find_by_sql(ab)
      redirect_to show_bookings_path
  end

 def save_room
    #@booking=Booking.new
    @newbooking = Booking.new(booking_params)
    @newbooking.bookday=Time.new
    @newbooking.username="admin"
    if @newbooking.save
       puts 'Booking was successfully created.'
       redirect_to show_bookings_path
    end

 end

  # POST /bookings
  # POST /bookings.json
  def create
    @booking = Booking.new(booking_params)

    respond_to do |format|
      if @booking.save
        format.html { redirect_to @booking, notice: 'Booking was successfully created.' }
        format.json { render :show, status: :created, location: @booking }
      else
        format.html { render :new }
        format.json { render json: @booking.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /bookings/1
  # PATCH/PUT /bookings/1.json
  def update
    respond_to do |format|
      if @booking.update(booking_params)
        format.html { redirect_to @booking, notice: 'Booking was successfully updated.' }
        format.json { render :show, status: :ok, location: @booking }
      else
        format.html { render :edit }
        format.json { render json: @booking.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /bookings/1
  # DELETE /bookings/1.json
  def destroy
    @booking.destroy
    respond_to do |format|
      format.html { redirect_to bookings_url, notice: 'Booking was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_booking
      @booking = Booking.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def booking_params
      params.require(:booking).permit(:room_id, :username, :string, :bookday, :date, :starttime, :endtime)
    end

    def room_params
      params.require(:room).permit(:size, :bulding)
    end
end
