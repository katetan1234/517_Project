Rails.application.routes.draw do
  resources :bookings
  get 'search' =>'bookings#search'
  post '/process_search', to: 'bookings#process_search'
  get 'release_room' =>'bookings#release_room'
  post '/release_room', to: 'bookings#release_room'
  post'/cancle', to: 'bookings#cancle'
  post '/save_room', to:'bookings#save_room'
  get '/save_room' =>'bookings#index'
  resources :rooms

  root"bookings#index"

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
